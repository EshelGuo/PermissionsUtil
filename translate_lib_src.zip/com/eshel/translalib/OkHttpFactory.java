package com.eshel.translalib;

import java.util.concurrent.TimeUnit;

import okhttp3.OkHttpClient;

/**
 * Created by guoshiwen on 2017/12/27.
 */

public class OkHttpFactory {
	private static OkHttpClient okHttpClient;
	public static OkHttpClient getOkHttpClient(){
		if(okHttpClient == null){
			synchronized (OkHttpFactory.class){
				if(okHttpClient == null){
					okHttpClient = new OkHttpClient.Builder()
							.connectTimeout(20, TimeUnit.SECONDS)
							.build();
				}
			}
		}
		return okHttpClient;
	}
}
