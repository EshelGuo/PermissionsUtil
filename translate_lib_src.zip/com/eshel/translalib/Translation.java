package com.eshel.translalib;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;

import com.google.common.io.BaseEncoding;

import org.json.JSONArray;
import org.json.JSONException;

import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

/**
 * Created by guoshiwen on 2017/12/27.
 */

public class Translation {
	private static String apiKey = "AIzaSyBc3bB3_fH-jw23z-39qm2zE-QvBbu4nDM";
	private static String REQUEST_URL = "https://www.googleapis.com/language/translate/v2";
	private static String PACKAGE_KEY = "X-Android-Package";
	private static String SHA1_KEY = "X-Android-Cert";
	public static void translate(Context context,String content,String targetLanguage, TranslationCallback callback){
		JSONArray array = new JSONArray();
		array.put(content);
		translate(context,array,targetLanguage,callback);
	}
	public static void translate(Context context, JSONArray contents, String targetLanguage, final TranslationCallback callback){
		OkHttpClient okHttpClient = OkHttpFactory.getOkHttpClient();
		String sig = getSignature(context.getPackageManager(),context.getPackageName());
		FormBody.Builder builder = new FormBody.Builder()
				.add("key", apiKey)
				.add("target", targetLanguage);
		for (int i = 0; i < contents.length(); i++) {
			String text;
			try {
				text = contents.getString(i);
				builder.add("q",text);
			} catch (JSONException e) {
				e.printStackTrace();
			}
		}
		FormBody formBody = builder.build();
		Request request = new Request.Builder()
				.url(REQUEST_URL)
				.header(PACKAGE_KEY,context.getPackageName())
				.header(SHA1_KEY,sig)
				.post(formBody)
				.build();
		Call call = okHttpClient.newCall(request);
		call.enqueue(new Callback() {
			@Override
			public void onFailure(Call call, IOException e) {
				callback.onTranslationFailed(e == null?"null":e.getMessage());
			}
			@Override
			public void onResponse(Call call, Response response) throws IOException {
				callback.onTranslationSuccess(response.body().string());
			}
		});
	}
	/**
	 * Gets the SHA1 signature, hex encoded for inclusion with Google Cloud Platform API requests
	 *
	 * @param packageName Identifies the APK whose signature should be extracted.
	 * @return a lowercase, hex-encoded
	 */
	private static String getSignature(PackageManager pm, String packageName) {
		try {
			PackageInfo packageInfo = pm.getPackageInfo(packageName, PackageManager.GET_SIGNATURES);
			if (packageInfo == null
					|| packageInfo.signatures == null
					|| packageInfo.signatures.length == 0
					|| packageInfo.signatures[0] == null) {
				return null;
			}
			return signatureDigest(packageInfo.signatures[0]);
		} catch (PackageManager.NameNotFoundException e) {
			return null;
		}
	}

	private static String signatureDigest(Signature sig) {
		byte[] signature = sig.toByteArray();
		try {
			MessageDigest md = MessageDigest.getInstance("SHA1");
			byte[] digest = md.digest(signature);
			return BaseEncoding.base16().lowerCase().encode(digest);
		} catch (NoSuchAlgorithmException e) {
			return null;
		}
	}
}
