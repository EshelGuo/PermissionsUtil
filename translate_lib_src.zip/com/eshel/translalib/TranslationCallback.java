package com.eshel.translalib;

/**
 * Created by guoshiwen on 2017/12/27.
 */

public interface TranslationCallback {
	void onTranslationSuccess(String resultJson);
	void onTranslationFailed(String errMsg);
}
